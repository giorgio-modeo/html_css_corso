What does ?v=1.0 do?
    <link rel="stylesheet" href="css/styles.css?v=1.0">
the expression '?v=1.0' is used to force the browser to use the latest version of css instead of the one saved in the cache

How does the browser cache work?
When you visit a website, your browser stores some of the website's files (like images, scripts, and stylesheets) on your device. When you visit the same website again, your browser can use these stored files instead of downloading them again. This makes the website load faster. 
