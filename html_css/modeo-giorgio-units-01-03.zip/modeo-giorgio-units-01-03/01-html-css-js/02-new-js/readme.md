empty page with javascript print in console
