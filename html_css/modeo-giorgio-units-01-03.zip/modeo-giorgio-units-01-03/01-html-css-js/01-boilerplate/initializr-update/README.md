
modified lines(10,19-481):
    10)rel="apple-touch-icon"  to this rel="icon" 
    19)import ajax
    19)split(19-20 lines) and modify paragraph
    20)
    22-28)  style rules for class btn
            modified    backgraund color
                        text color
                        moved to 50%

            style rules for class a-btn
            modified    size 
                        shadow

    34)button for reload page
    36)paragraph comparate with style to move in center page
    37)link disguised with button
    38-39)line breaks
    40)link disguised with button
